package com.example.shetu.activity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.shetu.Assets.MyPackages;
import com.example.shetu.Assets.User;
import com.example.shetu.R;
import com.example.shetu.Assets.RetrofitClient;
import com.example.shetu.models.AuthUsersResponse;
import com.example.shetu.models.OtpRqResponse;
import com.example.shetu.models.VerifyResponse;
import com.example.shetu.storage.SharedPrefManager;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    private Toolbar loginToolbar;
    private String mobile, otp;
    private Button LoginSendOtpBtn;
    private TextView  appBarTitle;
    //private CircleImageView appBarLogo;
    private EditText LoginPhnEt;
    private ProgressDialog progressDialog;

    private boolean newUser,otpSent;
    private String BSSID;
    private WifiInfo wifiInfo;
    private WifiManager wifiManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        progressDialog = new ProgressDialog(LoginActivity.this,
                R.style.AppTheme_Dark_Dialog);
        progressDialog.setIndeterminate(true);

        otpSent=false;
        //loginToolbar.findViewById(R.id.login_toolbar);
        appBarTitle = findViewById(R.id.app_toolbar_title);
        appBarTitle.setText(R.string.verify_toolbar_title);
//        appBarLogo = findViewById(R.id.logo_image);
//        appBarTitle.setText("");


        wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        wifiInfo = wifiManager.getConnectionInfo();
        BSSID=wifiInfo.getBSSID();




        LoginSendOtpBtn = findViewById(R.id.login_send_otp_btn);


        LoginPhnEt = findViewById(R.id.login_phn_et);




        LoginSendOtpBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (otpSent){
                    otp = LoginPhnEt.getText().toString();
                    if (TextUtils.isEmpty(mobile) || mobile.length() < 4) {
                        Toast.makeText(LoginActivity.this, "Enter Otp...!", Toast.LENGTH_LONG).show();
                        return;
                    }else{
                        VerifyUser();
                    }
                }else{
                    mobile = LoginPhnEt.getText().toString();
                    if (TextUtils.isEmpty(mobile) || mobile.length() != 11) {
                        Toast.makeText(LoginActivity.this, "Enter Valid Mobile Number...!", Toast.LENGTH_LONG).show();
                        return;
                    }else {
                        RequestOtp(mobile);
                    }
                }


            }
        });
    }

    private void RequestOtp(final String mobile) {
        progressDialog.setMessage("Requesting OTP...");
        progressDialog.show();
        Call<OtpRqResponse> call = RetrofitClient.getInstance().getApi().requestOTP(mobile);
        call.enqueue(new Callback<OtpRqResponse>() {

            @Override
            public void onResponse(Call<OtpRqResponse> call, Response<OtpRqResponse> response) {

                if (response.code()==200){
                    String msg = response.body().getMessage();
                    otpSent=true;

                    LoginPhnEt.setText("");
                    LoginPhnEt.setHint("OTP");
                    LoginSendOtpBtn.setText("Verify");
                    progressDialog.dismiss();
                    Toast.makeText(LoginActivity.this, msg, Toast.LENGTH_SHORT).show();
                }else if (response.code()==429){
                    progressDialog.dismiss();
                    final Dialog dialog = new Dialog(LoginActivity.this, R.style.DialogTheme);
                    dialog.setContentView(R.layout.dialog_already_sent_otp);
                    Button btton =  dialog.findViewById(R.id.verify_existing_otp_btn);
                    btton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            otpSent=true;
                            LoginPhnEt.setText("");
                            LoginPhnEt.setHint("OTP");
                            LoginSendOtpBtn.setText("Verify");
                            dialog.dismiss();
                        }
                    });
                    dialog.show();
                    //Toast.makeText(LoginActivity.this, "OTP sent already. Please try after 5 minutes.", Toast.LENGTH_SHORT).show();
                } else{
                    progressDialog.dismiss();
                    Toast.makeText(LoginActivity.this, "e"+response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<OtpRqResponse> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(LoginActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
        //return success[0];

    }

    private void VerifyUser() {
        progressDialog.setMessage("Authenticating...");
        progressDialog.show();
        Call<VerifyResponse> call = RetrofitClient.getInstance().getApi().Verify(mobile, otp, BSSID);
        call.enqueue(new Callback<VerifyResponse>() {
            @Override
            public void onResponse(Call<VerifyResponse> call, Response<VerifyResponse> response) {

                if (response.code()==200) {

                    VerifyResponse verifyResponse=response.body();
                    newUser=verifyResponse.getIs_new_user();
                    String token=verifyResponse.getData();

                    SharedPrefManager.getInstance(LoginActivity.this)
                            .saveToken(token);

                    progressDialog.dismiss();
                    if (!newUser){
                        Intent aIntent = new Intent(LoginActivity.this, MainActivity2.class);
                        aIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(aIntent);
                    }else{
                        Intent aIntent = new Intent(LoginActivity.this, RegisterActivity.class);
                        aIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(aIntent);
                    }

                } else {
                    progressDialog.dismiss();
                    Toast.makeText(LoginActivity.this, response.message(), Toast.LENGTH_SHORT).show();
                }

//                if (tkn!=null){
//                    try {
//                        JSONObject token = new JSONObject(tkn);
//                        Toast.makeText(LoginActivity.this, token.getString("data"), Toast.LENGTH_LONG).show();
//                    } catch (JSONException e) {
//                        e.printStackTrace();
//                    }
//                }

            }

            @Override
            public void onFailure(Call<VerifyResponse> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(LoginActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

}