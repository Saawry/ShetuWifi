package com.example.shetu.activity;

import com.example.shetu.models.DfltResponse;
import com.example.shetu.storage.SharedPrefManager;

import android.content.Intent;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.shetu.Assets.RetrofitClient;
import com.example.shetu.Assets.User;
import com.example.shetu.R;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProfileActivity extends AppCompatActivity {

    private Button ProfileLogoutBtn;
    private TextView ProfilePhoneTv;
    private String mobile, name, token;

    //private Token token;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        ProfileLogoutBtn = findViewById(R.id.prof_logout_btn);
        ProfilePhoneTv = findViewById(R.id.profile_phn_tv);

        //mobile=getIntent().getExtras().get("Mobile").toString();

        User user = SharedPrefManager.getInstance(this).getUser();
        token = SharedPrefManager.getInstance(this).getToken();
        mobile = user.getMobile();
        name = user.getName();
        ProfilePhoneTv.setText("");
        ProfileLogoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LogoutUser();
            }
        });

    }

    private void LogoutUser() {

        Call<DfltResponse> call = RetrofitClient.getInstance().getApi().logout("Bearer " + token);
        call.enqueue(new Callback<DfltResponse>() {
            @Override
            public void onResponse(Call<DfltResponse> call, Response<DfltResponse> response) {
                if (response.isSuccessful()) {
                    SharedPrefManager.getInstance(ProfileActivity.this).clear();
                    Toast.makeText(ProfileActivity.this, String.valueOf(response.message()), Toast.LENGTH_SHORT).show();
                    Intent aIntent = new Intent(ProfileActivity.this,AuthActivity.class);
                    startActivity(aIntent);
                }
            }

            @Override
            public void onFailure(Call<DfltResponse> call, Throwable t) {

            }
        });


//        OkHttpClient client = new OkHttpClient().newBuilder()
//                .build();
//        MediaType mediaType = MediaType.parse("text/plain");
//        RequestBody body = RequestBody.create(mediaType, "");
//        Request request = new Request.Builder()
//                .url("http://100.25.223.254:8080/v1/logout")
//                .method("DELETE", body)
//                .addHeader("Authorization", "Bearer "+token).build();
//        try {
//            okhttp3.Response response = client.newCall(request).execute();
//            if (response.isSuccessful()){
//                SharedPrefManager.getInstance(ProfileActivity.this).clear();
//                Toast.makeText(this, String.valueOf(response.code()), Toast.LENGTH_SHORT).show();
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
    }

}