package com.example.shetu.activity;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.InputType;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;

import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.shetu.R;
import com.example.shetu.Assets.RetrofitClient;
import com.example.shetu.models.DfltResponse;
import com.example.shetu.models.RegisterResponse;
import com.example.shetu.storage.SharedPrefManager;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Pattern;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterActivity extends AppCompatActivity {

    private String name, dob,token;
    private Button RegUpdateBtn;
    private TextView  appBarTitle;
    private EditText RegDobEt, RegNameEt;
    private ProgressDialog progressDialog;
    private Toolbar regToolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        progressDialog = new ProgressDialog(RegisterActivity.this,
                R.style.AppTheme_Dark_Dialog);
        progressDialog.setIndeterminate(true);

        regToolbar = findViewById(R.id.reg_toolbar);
        regToolbar.setVisibility(View.VISIBLE);
        appBarTitle = findViewById(R.id.app_toolbar_title);
        appBarTitle.setText(R.string.update_info_toolbar_title);


        RegUpdateBtn = findViewById(R.id.reg_register_btn);

        RegNameEt = findViewById(R.id.reg_name_et);
        RegDobEt = findViewById(R.id.reg_dob_et);

        RegUpdateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                token = SharedPrefManager.getInstance(RegisterActivity.this).getToken();
                name = RegNameEt.getText().toString();
                dob = RegDobEt.getText().toString();
                if (TextUtils.isEmpty(name)) {
                    Toast.makeText(RegisterActivity.this, "Enter Name", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(dob) || dob.length()<8) {
                    Toast.makeText(RegisterActivity.this, "Enter Valid Date of Birth", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(token)){
                    Toast.makeText(RegisterActivity.this, "Error, Verify OTP again", Toast.LENGTH_SHORT).show();
                    return;
                }
                UpdateUserInfo();
            }
        });
    }



    private void UpdateUserInfo() {
        progressDialog.setMessage("Updating");
        progressDialog.show();
        Call<DfltResponse> call = RetrofitClient.getInstance().getApi().UpdateInfo("Bearer "+token, name, dob);
        call.enqueue(new Callback<DfltResponse>() {
            @Override
            public void onResponse(Call<DfltResponse> call, Response<DfltResponse> response) {
                if (response.isSuccessful()) {
                    progressDialog.dismiss();
                    Toast.makeText(RegisterActivity.this, "Updated Successfully", Toast.LENGTH_SHORT).show();
                    SharedPrefManager.getInstance(RegisterActivity.this).saveData("name",name);
                    SendToMainActivity();
                }else{
                    progressDialog.dismiss();
                    Toast.makeText(RegisterActivity.this, response.code()+": "+response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<DfltResponse> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(RegisterActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }



    private void SendToMainActivity() {
        Intent aIntent = new Intent(RegisterActivity.this, MainActivity2.class);
        startActivity(aIntent);
    }

}