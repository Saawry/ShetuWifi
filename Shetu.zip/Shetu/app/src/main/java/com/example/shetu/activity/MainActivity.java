package com.example.shetu.activity;
import android.support.v7.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.StrictMode;
import android.text.format.Formatter;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.shetu.R;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class MainActivity extends AppCompatActivity {


//------------------

    private WifiManager wifiManager;
    private ListView listView;
    private Button buttonScan;
    private int size = 0;
    private List<ScanResult> results;
    private ArrayList<String> arrayList = new ArrayList<>();
    private ArrayAdapter adapter;


  //----------------


    String ipv4;
    int intIP;
    Button GetInfoBtn;
    TextView InfoTv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);


        wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        final WifiInfo wifiInfo = wifiManager.getConnectionInfo();


        GetInfoBtn = findViewById(R.id.btn_getinfo);
        InfoTv = findViewById(R.id.tv_display_info);
        buttonScan = findViewById(R.id.btn_wifi_connect);

        listView = findViewById(R.id.wifiList);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, arrayList);
        listView.setAdapter(adapter);
        //----------------



        GetInfoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int ip=wifiInfo.getIpAddress();


                //String ipFinal = Formatter.formatIpAddress(wifiManager.getConnectionInfo().getIpAddress());
                InetAddress localHost = null;
                try {
                    localHost = InetAddress.getLocalHost();

                } catch (UnknownHostException e) {
                    e.printStackTrace();
                }
                ipv4 = localHost.getHostAddress();

                try {
                    InetAddress i= InetAddress.getByName(String.valueOf(ipv4));
                    intIP= ByteBuffer.wrap(i.getAddress()).getInt();
                } catch (UnknownHostException e) {
                    e.printStackTrace();
                }


                //String finalIp=longToIp(intRp);

                String fip = longToIp(ip);
                String macAddress = wifiInfo.getMacAddress();
                String bssid= wifiInfo.getBSSID();
                String ssid= wifiInfo.getSSID();
                int networkId = wifiInfo.getNetworkId();
                int linkSpeed= wifiInfo.getLinkSpeed();

                InfoTv.setText(intIP+"--intIP\n"+ip+"--ip\n"+localHost+"--localHost\n"+ ipv4 +"--ipv4\n"+ fip +"--fip\n"+macAddress+"--mac\n"+ssid+"--ssid\n"+bssid+"--bssid\n"+networkId+"--nid\n");
            }
        });


        buttonScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!wifiManager.isWifiEnabled()) {
                    Toast.makeText(MainActivity.this, "WiFi is disabled ... We need to enable it", Toast.LENGTH_LONG).show();
                    wifiManager.setWifiEnabled(true);
                }
                scanWifi();
            }
        });


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //----------
                WifiConfiguration wifiConfig = new WifiConfiguration();
                //find ssid

                String sssid= (String) parent.getItemAtPosition(position);
                Toast.makeText(MainActivity.this, sssid, Toast.LENGTH_SHORT).show();
                wifiConfig.SSID = String.format("\"%s\"", sssid);
                wifiConfig.preSharedKey = String.format("\"%s\"", "gaddar@sma");
                //Toast.makeText(MainActivity.this, wifiConfig.preSharedKey, Toast.LENGTH_SHORT).show();

                ConnectToNetworkWPA("Gaddar","gaddar@sma");
//                try{
//                    int netId = wifiManager.addNetwork(wifiConfig);
//                    wifiManager.disconnect();
//                    wifiManager.enableNetwork(netId, true);
//                    wifiManager.reconnect();
//                }catch (Exception e){
//                    Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
//                }

//                int netId = wifiManager.addNetwork(wifiConfig);
//                wifiManager.disconnect();
//                wifiManager.enableNetwork(netId, true);
//                wifiManager.reconnect();
            }
        });



    }


    private void scanWifi() {
        arrayList.clear();
        registerReceiver(wifiReceiver, new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
        wifiManager.startScan();
        Toast.makeText(this, "Scanning WiFi ...", Toast.LENGTH_SHORT).show();
    }

    BroadcastReceiver wifiReceiver  = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            results = wifiManager.getScanResults();
            unregisterReceiver(this);

            for (ScanResult scanResult : results) {
                arrayList.add(scanResult.SSID + " - " + scanResult.capabilities);
                adapter.notifyDataSetChanged();
            }
        }
    };

    public String longToIp(long i) {

        return ((i >> 24) & 0xFF) +
                "." + ((i >> 16) & 0xFF) +
                "." + ((i >> 8) & 0xFF) +
                "." + (i & 0xFF);

    }

    public boolean ConnectToNetworkWPA( String networkSSID, String password )
    {
        try {
            Toast.makeText(this, "in ", Toast.LENGTH_SHORT).show();
            WifiConfiguration conf = new WifiConfiguration();
            conf.SSID = "\"" + networkSSID + "\"";   // Please note the quotes. String should contain SSID in quotes

            conf.preSharedKey = "\"" + password + "\"";

            conf.status = WifiConfiguration.Status.ENABLED;
            conf.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.TKIP);
            conf.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.CCMP);
            conf.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.WPA_PSK);
            conf.allowedPairwiseCiphers.set(WifiConfiguration.PairwiseCipher.TKIP);
            conf.allowedPairwiseCiphers.set(WifiConfiguration.PairwiseCipher.CCMP);

            Log.d("connecting", conf.SSID + " " + conf.preSharedKey);

            WifiManager wifiManagern = (WifiManager) this.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            wifiManagern.addNetwork(conf);

            Log.d("after connecting", conf.SSID + " " + conf.preSharedKey);

            List<WifiConfiguration> list = wifiManager.getConfiguredNetworks();
            for( WifiConfiguration i : list ) {
                if(i.SSID != null && i.SSID.equals("\"" + networkSSID + "\"")) {
                    wifiManagern.disconnect();
                    wifiManagern.enableNetwork(i.networkId, true);
                    wifiManagern.reconnect();
                    Log.d("re connecting", i.SSID + " " + conf.preSharedKey);

                    break;
                }
            }


            //WiFi Connection success, return true
            return true;
        } catch (Exception ex) {
            System.out.println(Arrays.toString(ex.getStackTrace()));
            return false;
        }
    }
}
